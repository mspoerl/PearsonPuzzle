/*
package controller;

import java.awt.event.ActionEvent;

import model.Model;
import view.View;

public class DesignController extends Controller{

	
	public DesignController(Model model, View view) {
		super(model, view);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

}
*/
