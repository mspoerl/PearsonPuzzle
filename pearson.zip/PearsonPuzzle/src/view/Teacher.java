package view;

public class Teacher extends Visitor{

}
